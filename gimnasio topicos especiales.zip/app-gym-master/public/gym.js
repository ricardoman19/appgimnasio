new Vue({
	el: '#app',
		data: {
			inscripcion: true,
			factura: true,
			asistencia: true,
			egreso: true,
			locker: true,
			mantenimiento: true,
			reporte: true,
			nuevo_inscripcion: false,
			cambio_plan: false,
			reinscripcion : false,
			plan: false,
			respaldo: false,
			caja_diaria: false,
			cuadre_caja: false,
			caja_locker: false,
			historial: false,
			registro: false,
			btn_plan: false,
			nuevo_plan: false,
			datos_reinscripcion: false,
			datos_cambio_plan: false,
			lista_factura: false,
			premium: 50,
			basico: 20,
			estandar: 30,
			mensaje: 'Inicio'
		},
		methods: {
			menu_inscripcion: function(){
				this.ocultar();
				this.nuevo_inscripcion = true;
				this.cambio_plan = true;
				this.reinscripcion = true;
				this.mensaje = 'Inscripcion';
			},
			registro_inscripcion: function(){
				if (this.nuevo_inscripcion) {
					this.nuevo_inscripcion = false;
					this.cambio_plan = false;
					this.reinscripcion = false;
					this.registro = true;
					this.btn_plan = true;
				}
			},
				registro_plan: function(){
					if (this.btn_plan) {
						this.btn_plan = false;
						this.registro = false;
						this.nuevo_plan = true;
					}
			},
				n_reinscripcion: function(){
					if (this.reinscripcion) {
						this.reinscripcion = false;
						this.nuevo_inscripcion = false;
						this.cambio_plan = false;
						this.reinscripcion = false;
						this.datos_reinscripcion = true;
					}
			},
				n_plan: function(){
					if (this.cambio_plan) {
						this.reinscripcion = false;
						this.nuevo_inscripcion = false;
						this.cambio_plan = false;
						this.reinscripcion = false;
						this.datos_reinscripcion = false;
						this.datos_cambio_plan = true;
					}
			},
				menu_factura: function(){
				this.ocultar();
				this.lista_factura = true;
				this.mensaje = 'Facturacion';
			},
				n_factura: function(){
					
			},
			    menu_egreso: function(){
			    this.ocultar();
				this.mensaje = 'Registros de egresos';
			},
				menu_asistencia: function(){
				this.ocultar();
				this.mensaje = 'Asistencias';
			},
				menu_mantenimiento: function(){
				this.ocultar();
				this.plan = true;
				this.respaldo = true;
				this.mensaje = 'Mantenimiento';
			},
				menu_reporte: function(){
				this.ocultar();
				this.cuadre_caja = true;
				this.historial = true;
				this.caja_diaria = true;
				this.caja_locker = true;
				this.mensaje = 'Reportes';
			},
				menu_locker: function(){
				this.ocultar();
				this.mensaje = 'Locker';
			},
				volver: function(){
				this.mostrar();
				this.nuevo_inscripcion = false;
				this.cambio_plan = false;
				this.reinscripcion = false;
				this.plan = false;
				this.respaldo = false;
				this.caja_locker = false;
				this.caja_diaria = false;
				this.cuadre_caja = false;
				this.historial = false;
				this.registro = false;
				this.btn_plan = false;
				this.nuevo_plan = false;
				this.datos_reinscripcion = false;
				this.datos_cambio_plan = false;
				this.lista_factura = false;
				this.mensaje = 'Inicio';
			},
				ocultar: function(){
				this.inscripcion = false;
				this.factura = false;
				this.asistencia = false;
				this.egreso = false;
				this.locker = false;
				this.mantenimiento = false;
				this.reporte = false;
			},
				mostrar: function(){
				this.inscripcion = true;
				this.factura = true;
				this.asistencia = true;
				this.egreso = true;
				this.locker = true;
				this.mantenimiento = true;
				this.reporte = true;
			}
		}
})